import axios from "axios";
import { useState } from "react";
import { Link } from "react-router-dom";
import "./App.css"; // Ensure you import your CSS file

function Register() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleRegister = async (e) => {
    e.preventDefault();
    if (password === confirmPassword) {
      try {
        await axios.post("http://localhost:3000/api/auth/register", {
          username,
          email,
          password,
        });
        alert("Registration successful");
      } catch (error) {
        alert(
          "Error registering: " +
            (error.response?.data?.message || "Unknown error")
        );
      }
    } else {
      alert("Passwords do not match");
    }
  };

  return (
    <div className="register-container">
      <div className="card">
        {" "}
        {/* Added card class for consistent styling */}
        <h2>Register</h2>
        <form onSubmit={handleRegister}>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <br />
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <br />
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <br />
          <label>Confirm Password:</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
          <br />
          <button type="submit">Register</button>
        </form>
        <p>
          Already have an account? <Link to="/login">Login here</Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
