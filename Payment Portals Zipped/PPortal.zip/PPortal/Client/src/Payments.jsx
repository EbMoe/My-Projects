// src/Payments.jsx
import React from "react";
import Navbar from "./Navbar";
import PaymentForm from "./PaymentForm";

function Payments({ handleLogout }) {
  return (
    <div>
      <Navbar handleLogout={handleLogout} />
      <h1>Payments Page</h1>
      <PaymentForm />
    </div>
  );
}

export default Payments;
