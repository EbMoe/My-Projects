// C:\Users\hkado\PPortal\Client\src\About.jsx
import React from "react";
import Navbar from "./Navbar";

function About({ handleLogout }) {
  return (
    <div>
      <Navbar handleLogout={handleLogout} />
      <h1>About Page</h1>
      {/* Add about content here */}
    </div>
  );
}

export default About;
