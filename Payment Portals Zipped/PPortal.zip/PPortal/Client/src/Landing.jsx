import { Link } from "react-router-dom";

function Landing() {
  return (
    <div>
      <h1>Welcome to the Payment Portal</h1>
      <p>Please choose an option:</p>
      <Link to="/login">
        <button>Login</button>
      </Link>
      <Link to="/register">
        <button>Register</button>
      </Link>
    </div>
  );
}

export default Landing;
