import { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom";

import Login from "./Login";
import Register from "./Register";
import Home from "./Home";
import Landing from "./Landing";
import Payments from "./Payments";
import About from "./About";
import "./App.css";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token); // Set to true if token exists
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Redirect to home if logged in, otherwise show Landing page */}
          <Route
            path="/"
            element={isLoggedIn ? <Navigate to="/home" /> : <Landing />}
          />
          {/* Route for login, passing down setIsLoggedIn */}
          <Route
            path="/login"
            element={<Login setIsLoggedIn={setIsLoggedIn} />}
          />
          {/* Route for registration */}
          <Route path="/register" element={<Register />} />
          {/* Home route, must be logged in to access */}
          <Route
            path="/home"
            element={
              isLoggedIn ? (
                <Home handleLogout={handleLogout} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          {/* Route for payments, must be logged in to access */}
          <Route
            path="/payments"
            element={
              isLoggedIn ? (
                <Payments handleLogout={handleLogout} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          {/* Route for about page, must be logged in to access */}
          <Route
            path="/about"
            element={
              isLoggedIn ? (
                <About handleLogout={handleLogout} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
        </Routes>
      </div>
    </Router>
  );
}
export default App;
