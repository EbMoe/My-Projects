// src/PaymentForm.jsx
import React, { useState } from "react";
import axios from "axios";

function PaymentForm() {
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("ZAR");
  const [provider, setProvider] = useState("");
  const [recipientAccount, setRecipientAccount] = useState("");
  const [swiftCode, setSwiftCode] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      await axios.post(
        "http://localhost:3000/api/payments",
        { amount, currency, provider, recipientAccount, swiftCode },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert("Payment submitted successfully");
    } catch (error) {
      alert("Error submitting payment");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Amount:</label>
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        required
      />

      <label>Currency:</label>
      <input
        type="text"
        value={currency}
        onChange={(e) => setCurrency(e.target.value)}
        required
      />

      <label>Provider:</label>
      <input
        type="text"
        value={provider}
        onChange={(e) => setProvider(e.target.value)}
        required
      />

      <label>Recipient Account:</label>
      <input
        type="text"
        value={recipientAccount}
        onChange={(e) => setRecipientAccount(e.target.value)}
        required
      />

      <label>SWIFT Code:</label>
      <input
        type="text"
        value={swiftCode}
        onChange={(e) => setSwiftCode(e.target.value)}
        required
      />

      <button type="submit">Submit Payment</button>
    </form>
  );
}

export default PaymentForm;
