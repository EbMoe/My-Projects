import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import authRoutes from './routes/auth.mjs';
import paymentRoutes from './routes/payments.mjs';
import morgan from 'morgan';  // For logging HTTP requests

const app = express();

// Middlewares
app.use(cors({ origin: 'http://localhost:5173' }));  // Enable CORS for your front-end
app.use(helmet());  // Adds security-related HTTP headers
app.use(express.json());  // Body parsing middleware
app.use(morgan('dev'));  // Log HTTP requests in 'dev' format

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/payments', paymentRoutes);
 
// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Internal server error:', err);  // Log the error for debugging
  res.status(500).json({ message: 'Internal server error' });  // Respond with a 500 status
});

// 404 Not Found middleware
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });  // Handle 404 errors
});

export default app;
