import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.mjs'; // Ensure your User model is properly defined
import ExpressBrute from 'express-brute';
import dotenv from 'dotenv';
import cors from 'cors'; // Import CORS for handling cross-origin requests

// Load environment variables
dotenv.config();

// Initialize the Express app
const app = express();

// Middleware
app.use(cors({ origin: 'http://localhost:5173' })); // Adjust port as necessary for your frontend
app.use(express.json()); // Middleware to parse JSON bodies

// Token generation function
const generateToken = (user) => {
  return jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
};

// Middleware to verify the token
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1]; // Extract token from Bearer token
  if (!token) {
    console.error("Token is required");
    return res.status(403).json({ message: 'Token is required' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      console.error("Invalid token", err);
      return res.status(403).json({ message: 'Invalid token' });
    }
    req.user = user; // Attach user information to the request
    next(); // Call the next middleware
  });
};

const router = express.Router();
const store = new ExpressBrute.MemoryStore();
const bruteForce = new ExpressBrute(store);

// Input validation patterns
const usernamePattern = /^[a-zA-Z0-9]{3,20}$/; // Alphanumeric, 3 to 20 characters
const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; // Simple email pattern
const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d!@#$%^&*]{8,}$/; // Password rules

// Middleware to validate input
const validateInput = (req, res, next) => {
  const { username, email, password } = req.body;

  if (!usernamePattern.test(username)) {
    console.error("Invalid username:", username);
    return res.status(400).json({ message: "Invalid username. Must be 3-20 alphanumeric characters." });
  }
  
  if (!emailPattern.test(email)) {
    console.error("Invalid email format:", email);
    return res.status(400).json({ message: "Invalid email format." });
  }
  
  if (!passwordPattern.test(password)) {
    console.error("Invalid password:", password);
    return res.status(400).json({ message: "Invalid password. Must be at least 8 characters long and include uppercase, lowercase letters, and a number." });
  }

  next(); // If all validations pass, proceed to the next middleware
};

// Registration Route
router.post('/register', validateInput, async (req, res) => {
  try {
    const { username, email, password } = req.body;

    console.log("Registration attempt for user:", { username, email });

    // Check if the user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      console.error("User already exists:", email);
      return res.status(400).json({ message: "User already exists" });
    }

    console.log("No existing user found, proceeding with registration.");

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    console.log("Password hashed successfully.");

    // Save the user with default role as 'user'
    const newUser = new User({ username, email, password: hashedPassword });
    await newUser.save();

    console.log("User registered successfully:", username);
    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    console.error("Error during registration:", error.message); // Log the error message
    res.status(500).json({ message: "Server error", error: error.message }); // Include error message in response
  }
});



// Login Route (with brute-force protection)
// Login Route (with brute-force protection)
router.post('/login', bruteForce.prevent, validateInput, async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find the user by email
    const user = await User.findOne({ email });
    if (!user) {
      console.error("Invalid credentials, user not found:", email);
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Check if the user has the "user" role
    if (user.role !== 'user') {
      console.error(`Login attempt denied for role: ${user.role}`);
      return res.status(403).json({ message: "Access denied: Only users can log in" });
    }

    // Compare the password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.error("Invalid credentials, password mismatch for user:", email);
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Generate JWT
    const token = generateToken(user);
    console.log("Login successful for user:", email);
    res.json({ token, message: "Login successful" });
  } catch (error) {
    console.error("Error during login:", error); // Log the error
    res.status(500).json({ message: "Server error" });
  }
});



// Check Auth Route
router.get('/check-auth', verifyToken, (req, res) => {
  res.json({ authenticated: true, user: req.user });
});


export default router;

export { verifyToken };

