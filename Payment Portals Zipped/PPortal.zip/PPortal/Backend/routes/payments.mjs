// routes/payments.mjs
import express from 'express';
import Payment from '../models/Payment.mjs';
import { verifyToken } from './auth.mjs'; // Ensure this function is accessible


const router = express.Router();

// POST /api/payments - Create a new payment
router.post('/', verifyToken, async (req, res) => {
  try {
    const { amount, currency, provider, recipientAccount, swiftCode } = req.body;
    const userId = req.user.id; // Assumes JWT contains user ID

    const newPayment = new Payment({
      userId,
      amount,
      currency,
      provider,
      recipientAccount,
      swiftCode,
    });

    await newPayment.save();
    res.status(201).json({ message: 'Payment created successfully' });
  } catch (error) {
    console.error('Error saving payment:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
